বাংলার সহায় — Android + Server Starter v1.0

এই প্যাকেজে আছে:
- আগের বাংলা-ডিফল্ট বাংলা/হিন্দি/ইংরেজি ওয়েব অ্যাপ
- Android Studio native WebView wrapper project
- Node.js/Express HTTPS hosting-এর জন্য backend starter
- Health endpoint এবং rate limiting/security headers
- OTP, AI ও booking integration-এর নিরাপদ placeholder

গুরুত্বপূর্ণ সীমাবদ্ধতা:
এটি এখন build/deploy starter, প্রকাশযোগ্য APK বা live production server নয়। এই কাজের পরিবেশে Android SDK/Gradle build tool নেই, তাই APK compile করা যায়নি। Android Studio-তে android ফোল্ডার খুলে SDK 35 ইনস্টল করে Build > Build APK(s) করতে হবে।

প্রথমে সার্ভার:
1) server ফোল্ডারে .env.example কপি করে .env করুন
2) npm install
3) npm start
4) HTTPS hosting-এ deploy করুন; /api/health পরীক্ষা করুন
5) Android/app/src/main/java/.../MainActivity.java-তে YOUR_HTTPS_DOMAIN_HERE বদলে প্রকৃত HTTPS URL দিন

তারপর APK:
1) Android Studio-তে android ফোল্ডার Open করুন
2) Android SDK Platform 35 ও compatible Android Gradle Plugin install/sync করুন
3) Build > Build APK(s)

Production চালুর আগে আবশ্যক:
- OTP provider নির্বাচন ও যাচাই; expiry, retry limit, abuse prevention
- user database, encrypted transport, privacy policy, consent ও account deletion
- AI provider server-side integration; API key কখনও APK/frontend-এ নয়
- Admin role, MFA/OTP, audit logs ও least privilege
- booking provider-এর অনুমোদিত API/affiliate flow; payment gateway-এর PCI-compliant hosted checkout
- HTTPS domain, backups, monitoring, vulnerability/security test

কোনও UPI PIN, card CVV বা banking password এই অ্যাপ সংগ্রহ করবে না।
